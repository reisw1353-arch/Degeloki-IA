# DEGELOKI — projeto inicial completo

Projeto Next.js preparado para editar pelo celular, enviar ao GitHub e publicar na Vercel. A conversa usa a API do Google Gemini pelo servidor; a chave não fica no navegador.

## O que já está incluído

- Chat conectado ao Gemini pela rota segura `/api/chat`.
- Personalidade irônica, direta e provocadora, com mudança de tom quando a pessoa demonstra tristeza.
- Histórico recente salvo no navegador.
- Memórias que a pessoa adiciona, remove e apaga manualmente (armazenadas apenas naquele navegador/dispositivo).
- Leitura em voz alta e reconhecimento de voz, quando o navegador oferece suporte.
- Layout responsivo para celular.

## Publicar usando GitHub e Vercel

1. Crie um repositório no GitHub chamado `degeloki`.
2. Envie todos os arquivos e pastas deste projeto para a raiz do repositório. Não envie `node_modules` nem arquivos `.env`.
3. Entre na Vercel usando sua conta GitHub e importe o repositório `degeloki`.
4. Antes de publicar, abra **Environment Variables** na configuração do projeto e adicione:
   - `GEMINI_API_KEY` = sua chave nova do Google AI Studio.
   - `GEMINI_MODEL` = `gemini-2.5-flash` (ou outro modelo disponível na sua conta).
5. Clique em Deploy. Se já tiver publicado antes de adicionar as variáveis, faça um novo redeploy.

## Segurança da chave

- Nunca coloque a chave em `app/page.tsx`, HTML, JavaScript do navegador ou em repositório público.
- Configure a chave somente nas variáveis de ambiente da Vercel.
- Se uma chave já foi compartilhada em conversa, print ou repositório, revogue-a e gere outra no Google AI Studio.
- Não envie sua chave para ninguém.

## Observações importantes

- A memória desta primeira versão fica no armazenamento local do navegador. Ela não sincroniza entre celulares ou navegadores e pode ser apagada se os dados do navegador forem limpos.
- A voz é fornecida pelo próprio navegador/dispositivo. A disponibilidade de voz feminina em português depende das vozes instaladas; esta versão tenta escolher uma voz pt-BR compatível, mas não garante uma voz específica.
- O microfone depende de permissão e suporte do navegador. Em geral, teste o site publicado em HTTPS pelo Chrome.
- Esta é uma base inicial funcional, não um serviço auditado para grande público. Antes de divulgar amplamente, adicione autenticação, limites de uso e proteção contra abuso para evitar consumo inesperado da API.

## Rodar localmente (opcional)

Requer Node.js instalado:

```bash
npm install
cp .env.example .env.local
# Edite .env.local e informe GEMINI_API_KEY
npm run dev
```

Abra `http://localhost:3000`.
